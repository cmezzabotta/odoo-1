# -*- coding: utf-8 -*-
import logging
import requests
from odoo import http
from odoo.http import request

_logger = logging.getLogger(__name__)

class MPPOSController(http.Controller):
    def _mp_headers(self):
        icp = request.env["ir.config_parameter"].sudo()
        token = icp.get_param("pos_mercadopago_direct.access_token")
        if not token:
            return None
        return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    @http.route("/mp/pos/create", type="json", auth="user")
    def mp_pos_create(self, amount, description="POS Order", external_reference=None):
        headers = self._mp_headers()
        if not headers:
            return {"error": "Falta Access Token en Ajustes."}
        body = {
            "items": [{
                "title": description or "POS Order",
                "quantity": 1,
                "currency_id": "ARS",
                "unit_price": float(amount),
            }],
            "external_reference": external_reference or "pos-order",
            "auto_return": "approved"
        }
        try:
            resp = requests.post("https://api.mercadopago.com/checkout/preferences", headers=headers, json=body, timeout=20)
            data = resp.json()
            if resp.status_code >= 300:
                _logger.error("MP create preference error %s: %s", resp.status_code, data)
                return {"error": data.get("message") or "Error creando preferencia"}
            return {"id": data.get("id"), "init_point": data.get("init_point"), "sandbox_init_point": data.get("sandbox_init_point")}
        except Exception as e:
            _logger.exception("MP create preference exception")
            return {"error": str(e)}

    @http.route("/mp/pos/status", type="json", auth="user")
    def mp_pos_status(self, preference_id):
        headers = self._mp_headers()
        if not headers:
            return {"error": "Falta Access Token en Ajustes."}
        try:
            url = f"https://api.mercadopago.com/merchant_orders?preference_id={preference_id}"
            resp = requests.get(url, headers=headers, timeout=20)
            data = resp.json()
            if resp.status_code >= 300:
                _logger.error("MP status error %s: %s", resp.status_code, data)
                return {"error": data.get("message") or "Error consultando estado"}
            results = data.get("elements") or []
            if not results:
                return {"status": "pending"}
            mo = results[0]
            payments = mo.get("payments") or []
            for p in payments:
                if p.get("status") == "approved":
                    return {"status": "approved", "transaction_amount": p.get("transaction_amount")}
            if payments:
                return {"status": payments[0].get("status")}
            return {"status": "pending"}
        except Exception as e:
            _logger.exception("MP status exception")
            return {"error": str(e)}
