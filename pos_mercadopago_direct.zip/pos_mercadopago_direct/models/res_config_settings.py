# -*- coding: utf-8 -*-
from odoo import models, fields

class ResConfigSettings(models.TransientModel):
    _inherit = "res.config.settings"

    mp_access_token = fields.Char(string="Mercado Pago Access Token", config_parameter="pos_mercadopago_direct.access_token")
    mp_public_key = fields.Char(string="Mercado Pago Public Key", config_parameter="pos_mercadopago_direct.public_key")
    mp_sandbox = fields.Boolean(string="Usar Sandbox", config_parameter="pos_mercadopago_direct.sandbox", default=True)
