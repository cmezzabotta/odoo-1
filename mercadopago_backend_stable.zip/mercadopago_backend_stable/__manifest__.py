{
    "name": "Mercado Pago Backend Stable",
    "version": "1.0",
    "summary": "Stable version with delayed view loading",
    "category": "Point of Sale",
    "depends": ["base"],
    "installable": True,
    "auto_install": False,
    "data": [],
    "post_init_hook": "load_views_after_model"
}