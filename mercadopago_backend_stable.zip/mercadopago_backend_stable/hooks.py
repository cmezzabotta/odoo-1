from odoo.tools import convert_file
import os

def load_views_after_model(cr, registry):
    module_path = os.path.dirname(__file__)
    xml_path = os.path.join(module_path, 'views', 'mercadopago_order.xml')
    convert_file(cr, 'mercadopago_backend_stable', xml_path, {}, 'init', False, 'en_US')