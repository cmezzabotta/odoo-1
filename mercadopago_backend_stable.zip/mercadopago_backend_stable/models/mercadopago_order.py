from odoo import models, fields

class MercadoPagoOrder(models.Model):
    _name = 'mercadopago.order'
    _description = 'Mercado Pago POS Order'

    reference = fields.Char(string="External Reference", required=True, index=True)
    paid = fields.Boolean(string="Paid", default=False)