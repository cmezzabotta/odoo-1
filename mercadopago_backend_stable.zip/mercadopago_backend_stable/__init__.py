from . import models, controllers
from .hooks import load_views_after_model