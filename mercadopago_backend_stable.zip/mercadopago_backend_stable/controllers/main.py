import requests
from odoo import http
from odoo.http import request

class MercadoPagoBackend(http.Controller):

    @http.route('/pos/create_mercadopago_order', type='json', auth='public', csrf=False)
    def create_mercadopago_order(self, **kwargs):
        order_ref = kwargs.get("reference")
        amount = kwargs.get("amount")
        access_token = "APP_USR-6724179307550211-101517-dea6eb093ed23ae0bc0db56c1cb3a634-442630041"
        collector_id = "442630041"
        pos_id = "QR_1"

        if not order_ref or not amount:
            return {"error": "Missing reference or amount"}

        # Create the order record
        env = request.env['mercadopago.order'].sudo()
        if not env.search([('reference', '=', order_ref)]):
            env.create({'reference': order_ref, 'paid': False})

        url = f"https://api.mercadopago.com/instore/orders/qr/seller/collectors/{collector_id}/pos/{pos_id}/qrs"
        headers = {"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"}
        payload = {
            "external_reference": order_ref,
            "title": f"POS {order_ref}",
            "total_amount": float(amount),
            "notification_url": "https://yourdomain.com/mercado_pago_webhook",
            "items": [{
                "title": "Venta POS",
                "unit_price": float(amount),
                "quantity": 1,
                "unit_measure": "unit",
                "total_amount": float(amount)
            }]
        }
        response = requests.post(url, headers=headers, json=payload)
        return response.json()

    @http.route('/mercado_pago_webhook', type='json', auth='public', csrf=False)
    def mercado_pago_webhook(self, **kwargs):
        data = request.jsonrequest
        ref = data.get('external_reference')
        status = data.get('status', '').lower()
        if ref and status == 'approved':
            order = request.env['mercadopago.order'].sudo().search([('reference', '=', ref)])
            if order:
                order.sudo().write({'paid': True})
        return {"status": "ok"}

    @http.route('/pos/mercado_pago_status/<string:ref>', type='json', auth='public', csrf=False)
    def check_payment_status(self, ref):
        order = request.env['mercadopago.order'].sudo().search([('reference', '=', ref)], limit=1)
        return {"paid": order.paid if order else False}