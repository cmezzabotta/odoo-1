# POS Proxy Services (Odoo 19)
Migración propuesta del módulo a Odoo 19 (Python 3.10+).

## Qué incluye
- `__manifest__.py` actualizado a 19 y bundles de assets modernos.
- Vistas heredadas para `res.config.settings`, `pos.payment.method` y `uom.uom`.
- Parches OWL para:
  - **Auto-factura**: fuerza `to_invoice` si `factura_automatica` está activa.
  - **Descarga PDF** post-validación: extensión segura de `PaymentScreen` que no rompe el flujo base.
  - **Botón Cierre Fiscal (CF)**: componente con template + hook JS listo para integrar con tu proxy.
- `security/ir.model.access.csv` sin referencias a modelos inexistentes.

## Pasos de instalación
1. Colocar el directorio `pos_proxy_service/` dentro del `addons_path` de Odoo 19.
2. Actualizar lista de apps y **instalar** el módulo.
3. En **Punto de Venta > Configuración**:
   - Activar “Impresora fiscal”.
   - Completar `proxy_fiscal_printer` y `version_printer`.
   - Activar `factura_automatica` y/o `descargar_factura_pdf` según necesidad.
4. Abrir el POS, realizar un ticket y validar:
   - Si `factura_automatica`: se forzará la facturación (`to_invoice = True`).
   - Si `descargar_factura_pdf`: tras validar, intentará descargar el PDF (requiere implementar RPC servidor).
   - Verás el botón **CF** en los botones de control si la impresora fiscal está habilitada.

## Pendientes de integración
- **RPC de PDF**: en `payment_pdf_download_patch.js` implementa la llamada a servidor, p. ej. `pos.order.action_download_invoice_pdf` que retorne un `ir.actions.report` o un action window para descargar.
- **Cierre fiscal real**: enlazar `PPSFiscalClosureButton.onClick()` a tu endpoint/proxy.

## Notas
- Si en tu código original hay lógica adicional (envío de ticket, apertura de caja, etc.), migra las partes concretas a los JS indicados y ajusta imports a rutas de Odoo 19.
- Si un XPath fallara por cambios de DOM, valida con el `pos.debug=1` (modo depuración) y ajusta el selector a un contenedor estable (usamos `//div[contains(@class,'control-buttons')]`).
