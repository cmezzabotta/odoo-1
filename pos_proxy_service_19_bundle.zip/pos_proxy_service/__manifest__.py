# -*- coding: utf-8 -*-
{
    "name": "POS Proxy Services",
    "summary": "Integración de proxy para impresora fiscal + utilidades POS (auto-factura, descarga PDF, cierre fiscal)",
    "version": "19.0.1.0.0",
    "author": "Pronexo / Cesar Mezzabotta",
    "website": "https://www.pronexo.com",
    "license": "AGPL-3",
    "category": "Point of Sale",
    "depends": [
        "point_of_sale",
        "account",
        "uom"
    ],
    "data": [
        "views/pos_config_view.xml",
        "views/pos_payment_method_view.xml",
        "views/uom_view.xml"
    ],
    "assets": {
        "web.assets_backend": [
            "pos_proxy_service/static/src/js/auto_factura.js",
            "pos_proxy_service/static/src/js/payment_pdf_download_patch.js",
            "pos_proxy_service/static/src/js/cierres_fiscales.js",
            "pos_proxy_service/static/src/js/send_ticket.js",
            "pos_proxy_service/static/src/xml/cierres_fiscales.xml"
        ]
    },
    "images": ["static/description/icon.png"],
    "installable": True,
    "application": False,
    "auto_install": False
}
