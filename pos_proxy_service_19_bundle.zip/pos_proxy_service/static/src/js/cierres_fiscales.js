/** @odoo-module */

import { Component } from "@odoo/owl";
import { registry } from "@web/core/registry";

export class PPSFiscalClosureButton extends Component {
    async onClick() {
        // Implementar llamada al proxy fiscal (RPC/HTTP) según tu backend.
        const notify = registry.category("notification");
        notify.add("Solicitando cierre fiscal al proxy…", { type: "info" });
        // TODO: RPC al backend/endpoint que hable con la impresora.
    }
}
PPSFiscalClosureButton.template = "pos_proxy_service.PPSFiscalClosureButton";
