/** @odoo-module */

import { PaymentScreen } from "@point_of_sale/app/screens/payment_screen/payment_screen";
import { patch } from "@web/core/utils/patch";
import { registry } from "@web/core/registry";

patch(PaymentScreen.prototype, {
    async _finalizeValidation() {
        await super._finalizeValidation(...arguments);

        try {
            if (this.pos?.config?.descargar_factura_pdf && this.currentOrder?.is_to_invoice()) {
                await this._pps_downloadInvoicePDF();
            }
        } catch (e) {
            // No interrumpir el flujo si la descarga falla.
            console.warn("POS Proxy Service: fallo descarga PDF de factura", e);
            const notify = registry.category("notification");
            notify.add(
                "No se pudo descargar el PDF de la factura.",
                { type: "warning" }
            );
        }
    },

    async _pps_downloadInvoicePDF() {
        // Ejemplo de RPC al backend: crear un controlador que reciba el order id
        // y devuelva el PDF (Base64) o un action para descargarlo.
        // Aquí dejamos un placeholder para implementar en tu controlador Python.
        // Nota: this.currentOrder.backendId suele ser el id de pos.order en server.
        const orderId = this.currentOrder?.backendId;
        if (!orderId) {
            return;
        }
        // TODO: implementar llamada RPC (this.rpc) a tu método que devuelva el PDF o el action.
        // Por ejemplo:
        // const action = await this.rpc({
        //     model: "pos.order",
        //     method: "action_download_invoice_pdf",
        //     args: [[orderId]],
        // });
        // this.env.services.action.doAction(action);

        // Placeholder: notificación para recordar implementar
        const notify = registry.category("notification");
        notify.add(
            "Descarga de PDF pendiente de implementar en el servidor (action_download_invoice_pdf).",
            { type: "info" }
        );
    },
});
